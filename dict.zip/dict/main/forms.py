from django.forms import ModelForm
from .models import dict

class simpleForm(ModelForm):
  class Meta:
    model = dict
    fields = '__all__'