from django.db import models

class dict(models.Model):
  input1 = models.CharField(max_length=150)
  input2 = models.CharField(max_length=150)

  def __str__(self):
    return str(self.input1 + " " + self.input2)
