from django.shortcuts import render,redirect
from django.db.models import Q
from .forms import simpleForm
from .models import dict

def home(request):
  form = simpleForm(request.POST)
  if request.method == "POST":
    if form.is_valid:
      form.save()
      redirect('/')
  context = {
    'form' : form
  }
  return render(request, 'index.html', context)

def search(request):
  query = request.GET.get('query')
  if query:
    dictionary = dict.objects.filter(Q(input1__icontains = query) | Q(input2__icontains=query))
    context = {'dict':dictionary}
    return render(request, 'search.html', context)
  context = {'query':query}
  return render(request, 'search.html', context)

    